package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class LoginDao extends User {
    @SuppressWarnings("unused")
    private String username;
    @SuppressWarnings("unused")
    private String email;
    @SuppressWarnings("unused")
    private String password;
    
    public void execute() throws Exception {
        Connection con = null;
        PreparedStatement ps = null;
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish MySQL database connection
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bmi_db", "root", "@Sarvani7");

            // Prepare SQL insert query
            ps = con.prepareStatement("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");

            // Set the values from the object properties
            ps.setString(1, getUsername());
            ps.setString(2, getEmail());
            ps.setString(3, getPassword());
            
            // Execute the update
            ps.executeUpdate();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Clean up resources
            if (ps != null) ps.close();
            if (con != null) con.close();
        }
    }

	public String authenticateUser(User loginBean) {
		// TODO Auto-generated method stub
		return null;
	}
}
